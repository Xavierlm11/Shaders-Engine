//
// engine.cpp : Put all your graphics stuff in this file. This is kind of the graphics module.
// In here, you should type all your OpenGL commands, and you can also type code to handle
// input platform events (e.g to move the camera or react to certain shortcuts), writing some
// graphics related GUI options, and so on.
//

#include "engine.h"
#include <imgui.h>
#include <stb_image.h>
#include <stb_image_write.h>
#include "Globals.h"
#include <glm/glm.hpp>
GLuint CreateProgramFromSource(String programSource, const char* shaderName)
{
	GLchar  infoLogBuffer[1024] = {};
	GLsizei infoLogBufferSize = sizeof(infoLogBuffer);
	GLsizei infoLogSize;
	GLint   success;

	char versionString[] = "#version 430\n";
	char shaderNameDefine[128];
	sprintf(shaderNameDefine, "#define %s\n", shaderName);
	char vertexShaderDefine[] = "#define VERTEX\n";
	char fragmentShaderDefine[] = "#define FRAGMENT\n";

	const GLchar* vertexShaderSource[] = {
		versionString,
		shaderNameDefine,
		vertexShaderDefine,
		programSource.str
	};
	const GLint vertexShaderLengths[] = {
		(GLint)strlen(versionString),
		(GLint)strlen(shaderNameDefine),
		(GLint)strlen(vertexShaderDefine),
		(GLint)programSource.len
	};
	const GLchar* fragmentShaderSource[] = {
		versionString,
		shaderNameDefine,
		fragmentShaderDefine,
		programSource.str
	};
	const GLint fragmentShaderLengths[] = {
		(GLint)strlen(versionString),
		(GLint)strlen(shaderNameDefine),
		(GLint)strlen(fragmentShaderDefine),
		(GLint)programSource.len
	};

	GLuint vshader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vshader, ARRAY_COUNT(vertexShaderSource), vertexShaderSource, vertexShaderLengths);
	glCompileShader(vshader);
	glGetShaderiv(vshader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vshader, infoLogBufferSize, &infoLogSize, infoLogBuffer);
		ELOG("glCompileShader() failed with vertex shader %s\nReported message:\n%s\n", shaderName, infoLogBuffer);
	}

	GLuint fshader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fshader, ARRAY_COUNT(fragmentShaderSource), fragmentShaderSource, fragmentShaderLengths);
	glCompileShader(fshader);
	glGetShaderiv(fshader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fshader, infoLogBufferSize, &infoLogSize, infoLogBuffer);
		ELOG("glCompileShader() failed with fragment shader %s\nReported message:\n%s\n", shaderName, infoLogBuffer);
	}

	GLuint programHandle = glCreateProgram();
	glAttachShader(programHandle, vshader);
	glAttachShader(programHandle, fshader);
	glLinkProgram(programHandle);
	glGetProgramiv(programHandle, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(programHandle, infoLogBufferSize, &infoLogSize, infoLogBuffer);
		ELOG("glLinkProgram() failed with program %s\nReported message:\n%s\n", shaderName, infoLogBuffer);
	}

	glUseProgram(0);

	glDetachShader(programHandle, vshader);
	glDetachShader(programHandle, fshader);
	glDeleteShader(vshader);
	glDeleteShader(fshader);

	return programHandle;
}

u32 LoadProgram(App* app, const char* filepath, const char* programName)
{
	String programSource = ReadTextFile(filepath);

	Program program = {};
	program.handle = CreateProgramFromSource(programSource, programName);
	program.filepath = filepath;
	program.programName = programName;
	program.lastWriteTimestamp = GetFileLastWriteTimestamp(filepath);

	GLint attributeCount = 0;
	glGetProgramiv(program.handle, GL_ACTIVE_ATTRIBUTES, &attributeCount);

	for (GLuint i = 0; i < attributeCount; i++)
	{
		GLsizei length = 0;
		GLint size = 0;
		GLenum type = 0;
		GLchar name[256];
		glGetActiveAttrib(program.handle, i,
			ARRAY_COUNT(name),
			&length,
			&size,
			&type,
			name);

		u8 location = glGetAttribLocation(program.handle, name);
		program.shaderLayout.attributes.push_back(VertexShaderAttribute{ location, (u8)size });
	}

	app->programs.push_back(program);

	return app->programs.size() - 1;
}

GLuint FindVAO(Mesh& mesh, u32 submeshIndex, const Program& program)
{
	GLuint ReturnValue = 0;

	SubMesh& Submesh = mesh.submeshes[submeshIndex];
	for (u32 i = 0; i < (u32)Submesh.vaos.size(); ++i)
	{
		if (Submesh.vaos[i].programHandle == program.handle)
		{
			ReturnValue = Submesh.vaos[i].handle;
			break;
		}
	}

	if (ReturnValue == 0)
	{
		glGenVertexArrays(1, &ReturnValue);
		glBindVertexArray(ReturnValue);

		glBindBuffer(GL_ARRAY_BUFFER, mesh.vertexBufferHandle);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.indexBufferHandle);

		auto& ShaderLayout = program.shaderLayout.attributes;
		for (auto ShaderIt = ShaderLayout.cbegin(); ShaderIt != ShaderLayout.cend(); ++ShaderIt)
		{
			bool attributeWasLinked = false;
			auto SubmeshLayout = Submesh.vertexBufferLayout.attributes;
			for (auto SubmeshIt = SubmeshLayout.cbegin(); SubmeshIt != SubmeshLayout.cend(); ++SubmeshIt)
			{
				if (ShaderIt->location == SubmeshIt->location)
				{
					const u32 index = SubmeshIt->location;
					const u32 ncomp = SubmeshIt->componentCount;
					const u32 offset = SubmeshIt->offset + Submesh.vertexOffset;
					const u32 stride = Submesh.vertexBufferLayout.stride;

					glVertexAttribPointer(index, ncomp, GL_FLOAT, GL_FALSE, stride, (void*)(u64)(offset));
					glEnableVertexAttribArray(index);

					attributeWasLinked = true;
					break;
				}
			}
			assert(attributeWasLinked);
		}
		glBindVertexArray(0);

		VAO vao = { ReturnValue, program.handle };
		Submesh.vaos.push_back(vao);
	}

	return ReturnValue;
}

glm::mat4 TransformScale(const vec3& scaleFactors)
{
	return glm::scale(scaleFactors);
}

glm::mat4 TransformPositionScale(const vec3& pos, const vec3& scaleFactors)
{
	glm::mat4 returnVal = glm::translate(pos);
	returnVal = glm::scale(returnVal, scaleFactors);
	return returnVal;
}
void Init(App* app)
{
	// TODO: Initialize your resources here!
	// - vertex buffers
	// - element/index buffers
	// - vaos
	// - programs (and retrieve uniform indices)
	// - textures

	//Get OPENGL info.
	app->openglDebugInfo += "OpeGL version:\n" + std::string(reinterpret_cast<const char*>(glGetString(GL_VERSION)));

	//VBO
	glGenBuffers(1, &app->embeddedVertices);
	glBindBuffer(GL_ARRAY_BUFFER, app->embeddedVertices);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	//ebo
	glGenBuffers(1, &app->embeddedElements);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, app->embeddedElements);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

	//VAO

	glGenVertexArrays(1, &app->vao);
	glBindVertexArray(app->vao);
	glBindBuffer(GL_ARRAY_BUFFER, app->embeddedVertices);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexV3V2), (void*)0);
	glEnableVertexAttribArray(0);
	//glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(VertexV3V2), (void*)12);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(VertexV3V2), (void*)sizeof(glm::vec3));
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, app->embeddedElements);
	glBindVertexArray(0);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

	//app->texturedGeometryProgramIdx = LoadProgram(app, "shaders.glsl", "TEXTURED_GEOMETRY");
	//const Program& texturedGeometryProgram = app->programs[app->texturedGeometryProgramIdx];
	//app->programUniformTexture = glGetUniformLocation(texturedGeometryProgram.handle, "uTexture");

	app->renderToBackBuffer = LoadProgram(app, "RENDER_TO_BB.glsl", "RENDER_TO_BB");

	app->renderToFrameBuffer = LoadProgram(app, "RENDER_TO_FB.glsl", "RENDER_TO_FB");
	app->FrameBufferToQuadShader = LoadProgram(app, "FB_TO_BB.glsl", "FB_TO_BB");
	//app->grindRenderShader = LoadProgram(app, "PRGrid.glsl", "GRID_SHADER");

	const Program& texturedMeshProgram = app->programs[app->renderToBackBuffer];
	app->texturedMeshProgram_uTexture = glGetUniformLocation(texturedMeshProgram.handle, "uTexture");
	u32 PatrickModelindex = ModelLoader::LoadModel(app, "Patrick/Patrick.obj");
	u32 SpongeModelindex = ModelLoader::LoadModel(app, "Patrick/SpongeBob.obj");
	u32 GroundModelindex = ModelLoader::LoadModel(app, "Patrick/ground.obj");
	
	u32 SphereModelindex = ModelLoader::LoadModel(app, "Patrick/Sphere.obj");
	u32 ConeModelindex = ModelLoader::LoadModel(app, "Patrick/Cone.obj");

	glEnable(GL_DEPTH_TEST);////////////////////////////////////////////////////////////////// PARA PROFUNDIIDAD
	glEnable(GL_CULL_FACE); // para que no pinte normales si no se ven

	glGetIntegerv(GL_MAX_UNIFORM_BLOCK_SIZE, &app->maxUniformBufferSize);
	glGetIntegerv(GL_UNIFORM_BUFFER_OFFSET_ALIGNMENT, &app->uniformBlockAlignment);

	app->localUniformBuffer = CreateConstantBuffer(app->maxUniformBufferSize); // crea un uniform buffer

	app->entities.push_back({ TransformPositionScale(vec3(5.0,0.0,-3.0),vec3(1.0,1.0,1.0)), PatrickModelindex,0,0 });
	app->entities.push_back({ TransformPositionScale(vec3(-5.0,0.0,-3.0),vec3(1.0,1.0,1.0)), PatrickModelindex,0,0 });
	//app->entities.push_back({ TransformPositionScale(vec3(5.0,-2.0,-2.0),vec3(1.0,1.0,1.0)), PatrickModelindex,0,0 });
	//app->entities.push_back({ TransformPositionScale(vec3(5.0,-2.0,-2.0),vec3(1.0,1.0,1.0)), SpongeModelindex,0,0 });
	app->entities.push_back({ TransformPositionScale(vec3(0.0,-2.0,3.0),vec3(1.0,1.0,1.0)), SpongeModelindex,0,0 });

	app->entities.push_back({ TransformPositionScale(vec3(0.0, -5.0, 0.0), vec3(1.0, 1.0, 1.0)), GroundModelindex,0,0 });

	
	app->lights.push_back({ LightType::LightType_Directional,vec3(1.0,1.0,1.0),vec3(1.0,-1.0,1.0),vec3(0.0,5.0,0.0) });
	app->lights.push_back({ LightType::LightType_Point,vec3(0.0,0.0,3.0),vec3(1.0,1.0,1.0),vec3(10.0,2.0,1.0) });
	app->lights.push_back({ LightType::LightType_Point,vec3(3.0,0.0,0.0),vec3(1.0,1.0,1.0),vec3(-10.0,2.0,1.0) });

	for (int i = 0; i < app->lights.size(); i++)
	{
		if(app->lights[i].type == LightType::LightType_Point)
			app->entities.push_back({ TransformPositionScale((app->lights[i].position), vec3(0.5, 0.5, 0.5)), SphereModelindex,0,0});
		else
			app->entities.push_back({ TransformPositionScale((app->lights[i].position), (-app->lights[i].direction)), ConeModelindex,0,0 });
		
	}

	app->ConfigureFrameBuffer(app->defferedFrameBuffer);

	app->cam.position = vec3(9.0f, 2.0f, 15.0f);
	app->cam.target = vec3(0.0f, 0.0f, -1.0f);
	app->cam.up = vec3(0.0f, 1.0f, 0.0f);
	app->cam.speed = 0.1f;
	app->cam.sensitivity = 0.05f;
	app->cam.front = vec3(0.0f, 0.0f, -1.0f);
	app->firstClick = true;

	app->mode = Mode_Deferred;
}

void Gui(App* app)
{
	ImGui::Begin("Info");
	ImGui::Text("FPS: %f", 1.0f / app->deltaTime);
	ImGui::Text("%s", app->openglDebugInfo.c_str());

	const char* renderModes[] = { "FORWARD","DEFERRED" };
	if (ImGui::BeginCombo("Render Mode", renderModes[app->mode]))
	{
		for (size_t i = 0; i < ARRAY_COUNT(renderModes); ++i)
		{
			bool isSelected = (i == app->mode);
			if (ImGui::Selectable(renderModes[i], isSelected)) //recordar esto no va bien
			{
				app->mode = static_cast<Mode>(i);
			}
		}

		ImGui::EndCombo();
	}
	if (app->mode == Mode::Mode_Deferred)
	{
		const char* modes[] = { "Albedo", "Normals", "Position", "ViewDir", "Depth" };
		for (size_t i = 0; i < app->defferedFrameBuffer.colorAttachment.size(); i++)
		{
			ImGui::Text(modes[i]);
			ImGui::Image((ImTextureID)app->defferedFrameBuffer.colorAttachment[i], ImVec2(300, 150), ImVec2(0, 1), ImVec2(1, 0));
		}

	}
	ImGui::End();
}

void Update(App* app)
{
	// You can handle app->input keyboard/mouse here
	bool movingCam = false;
	float sensivity = 1.4f;
	
	if (app->input.keys[Key::K_W] == ButtonState::BUTTON_PRESSED)
	{
		app->cam.position += app->cam.front * app->cam.speed;
	}
	if (app->input.keys[Key::K_A] == ButtonState::BUTTON_PRESSED)
	{
		app->cam.position -= glm::normalize(cross(app->cam.front, app->cam.up)) * app->cam.speed;
	}
	if (app->input.keys[Key::K_S] == ButtonState::BUTTON_PRESSED)
	{
		app->cam.position -= app->cam.front * app->cam.speed;
	}
	if (app->input.keys[Key::K_D] == ButtonState::BUTTON_PRESSED)
	{
		app->cam.position += glm::normalize(cross(app->cam.front, app->cam.up)) * app->cam.speed;
	}

	// Actualizar direcci�n frontal (front)
	app->cam.right = normalize(cross(app->cam.front, app->cam.up));
	app->cam.up = normalize(cross(app->cam.right, app->cam.front));

	app->cam.target = app->cam.position + app->cam.front;
}


void Render(App* app)
{
	switch (app->mode)
	{
	case Mode_Forward:
	{

		app->UpdateEntityBuffer();

		glBindFramebuffer(GL_FRAMEBUFFER, 0);

		glClearColor(0.f, 0.f, 0.f, .0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glViewport(0, 0, app->displaySize.x, app->displaySize.y);
		//glBindFramebuffer(GL_FRAMEBUFFER, app->defferedFrameBuffer.fbHandle);

		const Program& ForwardProgram = app->programs[app->renderToBackBuffer];
		glUseProgram(ForwardProgram.handle);

		app->RenderGeometry(ForwardProgram);

		//BufferManager::UnindBuffer(app->localUniformBuffer);
	}
	break;
	case Mode_Deferred:
	{

		app->UpdateEntityBuffer();

		//RENDER TO FB COLORaTT
		glClearColor(0.f, 0.f, 0.f, .0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glViewport(0, 0, app->displaySize.x, app->displaySize.y);
		glBindFramebuffer(GL_FRAMEBUFFER, app->defferedFrameBuffer.fbHandle);
		glDrawBuffers(app->defferedFrameBuffer.colorAttachment.size(), app->defferedFrameBuffer.colorAttachment.data());
		glClearColor(0.f, 0.f, 0.f, .0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		const Program& DeferredProgram = app->programs[app->renderToFrameBuffer];
		glUseProgram(DeferredProgram.handle);

		app->RenderGeometry(DeferredProgram);
		glBindFramebuffer(GL_FRAMEBUFFER, 0);
		//BufferManager::UnindBuffer(app->localUniformBuffer);

		//RENDER TO bb FROM cOLORaTT
		glClearColor(0.f, 0.f, 0.f, .0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glViewport(0, 0, app->displaySize.x, app->displaySize.y);

		//////RenderGrid
		//GLuint drawBuffers[] = { GL_COLOR_ATTACHMENT4 };
		//glDrawBuffers(1, drawBuffers);

		//glEnable(GL_DEPTH_TEST);
		//glEnable(GL_BLEND);
		//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		//
		//GLuint gridHandle = app->programs[app->grindRenderShader].handle;
		//glUseProgram(gridHandle);

		//vec4 tblr = app->cam2.GetTopBottomLeftRight();
		//glUniform1f(glGetUniformLocation(gridHandle, "left"),tblr.x );
		//glUniform1f(glGetUniformLocation(gridHandle, "right"), tblr.y);
		//glUniform1f(glGetUniformLocation(gridHandle, "bottom"), tblr.z);
		//glUniform1f(glGetUniformLocation(gridHandle, "top"), tblr.w);
		//glUniform1f(glGetUniformLocation(gridHandle, "znear"), app->cam2.zNear);
		//
		//glm::mat4 transMat = glm::translate(glm::mat4(1.0f), app->cam.position);
		//glm::mat4 yawMat = glm::rotate(glm::mat4(1.0), glm::radians(app->cam.yaw), glm::vec3(0, 1, 0));
		//glm::mat4 pitchMat = glm::rotate(glm::mat4(1.0), glm::radians(app->cam.pitch), glm::vec3(1, 0, 0));
		//glm::mat4 rotationMat = yawMat * pitchMat;
		//glm::mat4 

		//glUniformMatrix4fv(glGetUniformLocation(gridHandle, "worldMatrix"),1, );
		////glUniformMatrix4fv(glGetUniformLocation(gridHandle, "viewMatrix"),1, );

		//glBindVertexArray(app->vao);
		//glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, 0);

		//glBindVertexArray(0);
		//glUseProgram(0);

		//////
		//glBindFramebuffer(GL_FRAMEBUFFER, 0);
		//glDisable(GL_BLEND);


		const Program& FBToBB = app->programs[app->FrameBufferToQuadShader];
		glUseProgram(FBToBB.handle);



		/////
		glBindBufferRange(GL_UNIFORM_BUFFER, BINDING(0), app->localUniformBuffer.handle, app->globalPatamsOffset, app->globalPatamsSize);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, app->defferedFrameBuffer.colorAttachment[0]);
		glUniform1i(glGetUniformLocation(FBToBB.handle, "uAlbedo"), 0);

		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, app->defferedFrameBuffer.colorAttachment[1]);
		glUniform1i(glGetUniformLocation(FBToBB.handle, "uNormals"), 1);

		glActiveTexture(GL_TEXTURE2);
		glBindTexture(GL_TEXTURE_2D, app->defferedFrameBuffer.colorAttachment[2]);
		glUniform1i(glGetUniformLocation(FBToBB.handle, "uPosition"), 2);

		glActiveTexture(GL_TEXTURE3);
		glBindTexture(GL_TEXTURE_2D, app->defferedFrameBuffer.colorAttachment[3]);
		glUniform1i(glGetUniformLocation(FBToBB.handle, "uViewDir"), 3);


		glBindVertexArray(app->vao);
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, 0);

		//glBindTexture(GL_TEXTURE_2D, 0);
		glBindVertexArray(0);
		glUseProgram(0);
		//glBindFramebuffer(GL_FRAMEBUFFER, 0);

	}
	break;
	default:;
	}
}

void App::UpdateEntityBuffer()
{

	cam2.aspRatio = (float)displaySize.x / (float)displaySize.y;
	cam2.fovYRad = glm::radians(60.0f);
	glm::mat4 projection = glm::perspective(glm::radians(60.0f), cam2.aspRatio, cam2.zNear, cam2.zFar);

	//vec3 target = vec3(0.f, 0.f, 0.f);
	//vec3 camPos = vec3(5.0, 5.0, 5.0);


	//vec3 zCam = glm::normalize(cam.position - target);
	vec3 xCam = glm::cross(cam.front, vec3(0, 1, 0));
	vec3 yCam = glm::cross(xCam, cam.front);

	glm::mat4 view = glm::lookAt(cam.position, cam.target, yCam);
	BufferManager::MapBuffer(localUniformBuffer, GL_WRITE_ONLY);

	//push lights globals paramas
	globalPatamsOffset = localUniformBuffer.head;
	PushVec3(localUniformBuffer, cam.position);
	PushUInt(localUniformBuffer, lights.size());
	for (u32 i = 0; i < lights.size(); ++i)
	{
		BufferManager::AlignHead(localUniformBuffer, sizeof(vec4));

		Light& light = lights[i];
		PushUInt(localUniformBuffer, light.type);
		PushVec3(localUniformBuffer, light.color);
		PushVec3(localUniformBuffer, light.direction);
		PushVec3(localUniformBuffer, light.position);
	}

	globalPatamsSize = localUniformBuffer.head - globalPatamsOffset;

	//local parms

	u32 iteration = 0;
	for (auto it = entities.begin(); it != entities.end(); ++it)
	{
		glm::mat4 world = it->worldMatrix;
		glm::mat4 WVP = projection * view * world; //wordl view projection


		Buffer& localBuffer = localUniformBuffer;
		BufferManager::AlignHead(localBuffer, uniformBlockAlignment);
		it->localParamsOffset = localBuffer.head;
		PushMat4(localBuffer, world);
		PushMat4(localBuffer, WVP);
		it->localParamsSize = localBuffer.head - it->localParamsOffset;
		++iteration;
	}
	BufferManager::UnmapBuffer(localUniformBuffer);
}

void App::ConfigureFrameBuffer(FrameBuffer& aConfigFb)
{
	//GLuint NUMBER_OF_CA = 3; // esto cambeir si se a�aden en el shader


	aConfigFb.colorAttachment.push_back(CreateTexture());
	aConfigFb.colorAttachment.push_back(CreateTexture(true));
	aConfigFb.colorAttachment.push_back(CreateTexture(true));
	aConfigFb.colorAttachment.push_back(CreateTexture(true));
	aConfigFb.colorAttachment.push_back(CreateTexture(true));
	//aConfigFb.colorAttachment.push_back(CreateTexture());

	glGenTextures(1, &aConfigFb.depthHandle);
	glBindTexture(GL_TEXTURE_2D, aConfigFb.depthHandle);
	//EL BUFFEER OCUPA MAS,, si hay o�problema scon el z fight aumentar la cantidad de bits
	glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, displaySize.x, displaySize.y, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);  //RGBA para .si hacemos un resice que vuelva a generar el frame buff
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glBindTexture(GL_TEXTURE_2D, 0);

	glGenFramebuffers(1, &aConfigFb.fbHandle);
	glBindFramebuffer(GL_FRAMEBUFFER, aConfigFb.fbHandle);

	std::vector<GLuint> drawBuffers;
	for (size_t i = 0; i < aConfigFb.colorAttachment.size(); ++i)
	{
		GLuint position = GL_COLOR_ATTACHMENT0 + i;
		glFramebufferTexture(GL_FRAMEBUFFER, position, aConfigFb.colorAttachment[i], 0);
		drawBuffers.push_back(position);
	}

	glFramebufferTexture(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, aConfigFb.depthHandle, 0);

	glDrawBuffers(drawBuffers.size(), drawBuffers.data());


	GLenum framebufferStatus = glCheckFramebufferStatus(GL_FRAMEBUFFER);
	if (framebufferStatus != GL_FRAMEBUFFER_COMPLETE)
	{
		int i = 0;
	}

	//GLenum frameBufferStatus = glCheckFramebufferStatus(GL_FRAMEBUFFER);
	/// Aqui va u nif , TUDU
   // glDrawBuffers(1, &app->colorAttachmentHandle);
	glBindFramebuffer(GL_FRAMEBUFFER, 0);

}

void App::RenderGeometry(const Program& aBindedProgram)
{
	glBindBufferRange(GL_UNIFORM_BUFFER, BINDING(0), localUniformBuffer.handle, globalPatamsOffset, globalPatamsSize);
	for (auto it = entities.begin(); it != entities.end(); ++it)
	{

		glBindBufferRange(GL_UNIFORM_BUFFER, BINDING(1), localUniformBuffer.handle, it->localParamsOffset, it->localParamsSize); //todu creo q aqui no va, creo que es modelloading que no va

		Model& model = models[it->modelIndex];
		Mesh& mesh = meshes[model.meshIdx];


		for (u32 i = 0; i < mesh.submeshes.size(); ++i)
		{
			GLuint vao = FindVAO(mesh, i, aBindedProgram);
			glBindVertexArray(vao);

			u32 subMeshmaterialIdx = model.materialIdx[i];
			Material subMeshMaterial = materials[subMeshmaterialIdx];

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, textures[subMeshMaterial.albedoTextureIdx].handle);
			glUniform1i(texturedMeshProgram_uTexture, 0);

			SubMesh& submesh = mesh.submeshes[i];
			glDrawElements(GL_TRIANGLES, submesh.indices.size(), GL_UNSIGNED_INT, (void*)(u64)submesh.indexOffset);
		}

	}

}

const GLuint App::CreateTexture(const bool isFloatingPoint)
{
	GLuint textureHandle;

	GLenum internalFormat = isFloatingPoint ? GL_RGBA16F : GL_RGBA8;
	GLenum format = GL_RGBA;
	GLenum dataType = isFloatingPoint ? GL_FLOAT : GL_UNSIGNED_BYTE;

	glGenTextures(1, &textureHandle);
	glBindTexture(GL_TEXTURE_2D, textureHandle);
	glTexImage2D(GL_TEXTURE_2D, 0, internalFormat, displaySize.x, displaySize.y, 0, format, dataType, NULL);  //RGBA para .si hacemos un resice que vuelva a generar el frame buff
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glBindTexture(GL_TEXTURE_2D, 0);

	return textureHandle;
}

//vec4 App::Camera2::GetTopBottomLeftRight() //tudo
//{
//	vec4 returnValue;
//
//	//top
//	returnValue.x = tan(fovYRad / 2) * zNear;
//	//top
//	returnValue.y =-returnValue.y;
//	//top
//	returnValue.z = returnValue.x * aspRatio;
//	//top
//	returnValue.w = tan(fovYRad / 2) * zNear;
//
//
//	return vec4();
//}


